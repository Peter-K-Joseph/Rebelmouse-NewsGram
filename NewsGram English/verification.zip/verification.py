import requests
from bs4 import BeautifulSoup
import csv
import json
from pprint import pprint
import wget
from datetime import datetime
import matplotlib.pyplot as plt
import time

# Configuration
header = {
    'User-Agent': 'PostmanRuntime/7.28.0',
    'Accept': '*/*',
    'Cache-Control': 'no-cache',
    'Postman-Token': '3381a69f-f418-41b3-89a4-33b1106fd976',
    'Host': 'newsgram.rebelmouse.dev',
    'Accept-Encoding': 'gzip%2C deflate%2C br',
    'Connection': 'keep-alive',
    'Authorization': 'Basic bmV3c2dyYW06bmV3czIwMjE='
}
recieving_server = "https://newsgram.rebelmouse.dev/"
requesting_server = "https://www.newsgram.com/"
start = 70
end = 110

# Data Collection Point
returnData_404 = []
unverified = []

stat = [0, 0, 0]


def down():
    time.sleep(300)


def verify_upload(link, respond, prop, title):
    global header
    page = requests.get(link, headers=header)
    if (str(page) != "<Response [200]>" and str(page) != "<Response [404]>"):
        print("[PAUSED] Server Responded with " +
              str(page) + ". Retrying after 60 seconds")
        down()
        verify_upload(link, respond, prop, title)
    elif (str(page) == "<Response [404]>"):
        print("[" + str(((respond - 1) * 100) + prop) + "][FAILED] " + title)
        return True
    else:
        try:
            print("[" + str(((respond - 1) * 100) + prop) + "][SUCCESS] " + title)
            return False
        except:
            return "e"


def run():
    global header, recieving_server, requesting_server, start, end, stat
    for respond in range(start, end):
        page = requests.get(
            requesting_server + "wp-json/wp/v2/posts/?page=" + str(respond) + "&per_page=100")
        print("[GET] A GET request was sent to " + requesting_server +
              "wp-json/wp/v2/posts/?page=" + str(respond) + "&per_page=100")
        page = json.loads(page.text)
        for prop in range(0, len(page)):
            response = verify_upload(page[prop]["link"].replace(requesting_server, recieving_server), respond, prop, page[prop]["title"]["rendered"])
            if (response == True):
                returnData_404.append(response[prop]["id"])
                stat[1] = stat[1] + 1
            elif (response == "e"):
                print("[" + str(((respond - 1) * 100) + prop) + "][UNVERIFIED] " + page[prop]["title"]["rendered"])
                unverified.append(response[prop]["id"])
                stat[2] = stat[2] + 1
            else:
                stat[0] = stat[0] + 1
                
            if (respond % 25 == 0 and prop == 1):
                represent()


def represent():
    labels = 'Success', 'Failed', 'Unverified'
    sections = [stat[0], stat[1], stat[2]]
    colors = ['g', 'r', 'y']

    plt.pie(sections, labels=labels, colors=colors,
            startangle=90,
            explode=(0, 0.1, 0),
            autopct='%1.2f%%')

    plt.title('NewsGram Post Transfer Verification')
    plt.show()


run()
print("Failed\n")
print(returnData_404)
print("\n\nUnverified\n")
print(unverified)
